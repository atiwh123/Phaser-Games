class scene1{

    constructor(){

    }


    preload(){
        //load game images
        this.load.image('background','./assets/background12.png');
        this.load.image('cannon','./assets/cannon.png');
        this.load.image('cannonBall','./assets/cannonBall.png');
        this.load.image('pirateShip','./assets/pirateShip.png');
    }

    create(){

        //Create image using setOrigin
        this.add.image(0,0,'background').setOrigin(0,0);

        //cannon creation according to the ship in the background
        this.cannon=this.physics.add.sprite(384,256,'cannon');
        //cannonball creation according to the cannon
        this.cannonball=this.physics.add.sprite(384,256,'cannonBall');

        //create pirate ship
        this.pirateship=this.physics.add.group();
        this.pirateship.create(100,100,'pirateShip');
        this.pirateship.create(600,100,'pirateShip');
        this.pirateship.create(100,400,'pirateShip');
        this.pirateship.create(600,400,'pirateShip');

        this.control = false;

        //for mouse click event
        this.mouse=this.input.mousePointer;
        //for mouse position
        this.input=this.input;

        //set game bounds
        this.worldBounds=this.physics.world.bounds;
        

    }

    update(){


        //angle between mouse and ball
        let angle=Phaser.Math.Angle.Between(this.cannon.x,this.cannon.y,this.input.x,this.input.y);
        //rotation cannon with PI/2
        this.cannon.setRotation(angle+Math.PI/2);

        //mouse clicked
        if(this.mouse.isDown&& this.control==false){
            //for fire again
            this.cannonball=this.physics.add.sprite(384,256,'cannonBall');
            //move to mouse position 
            this.physics.moveTo(this.cannonball,this.input.x,this.input.y,500);
            this.control=true;
        }

        //check world bounds
        if(this.cannonball.x>this.worldBounds.width || this.cannonball.y>this.worldBounds.height ||this.cannonball.x<0 || this.cannonball.y<0){
            this.control=false;
        }

        //for collision
        this.physics.add.overlap(this.cannonball,this.pirateship,this.destroy,null,this);
        

    }

    destroy(cannonball,pirateship) {
        pirateship.disableBody(true,true);
        cannonball.disableBody(true,true);
        this.control=false;
}


    
}

//collide cannonbal and pirateShip


//create scene object


//create config for game object
var config={
    type:Phaser.AUTO,
    width:768,
    height:512,
    scene:scene1,
    physics:{
        default:'arcade',
        arcade:{
            gravity:{y:0}
        }
    }
};
//create phaser game
var game =new Phaser.Game(config);