var mainsc = new Phaser.Scene('scene1');

mainsc.init = function(){
	this.click = 0;
	this.start = 0;
	this.len = 0;
	this.x = 0;
	this.score = 0;
	var scoreText;
	var introText;
	this.go = false;

}

mainsc.preload = function(){
	this.load.image('bg', 'assets/b2.jpg');

	this.load.image('red', 'assets/r.png');
	this.load.image('green', 'assets/g.png');
	this.load.image('black', 'assets/b.png');
	this.load.image('ball', 'assets/ball.png');
}

mainsc.create = function(){

	this.bg = this.add.image(0,0,'bg');
	this.bg.setOrigin(0,0);
	this.bg.setScale(1.12);

	scoreText = this.add.text(32, 350, 'score: ' + this.score, { font: "20px Arial", fill: "#ffffff", align: "left" });
	introText = this.add.text(250, 200, 'Press to Start' , { font: "40px Arial", fill: "#ffffff", align: "left" });
	introText.visible = true;

	this.player = this.physics.add.sprite(this.sys.game.config.width /2, 380,'red');
	this.player.setScale(0.05);

	this.ball = this.physics.add.sprite(this.player.x / 2, this.player.y - 25, 'ball');
	this.ball.setScale(0.05);

	

	this.bGroup = this.add.group();

	while (this.len < 6){
		var black = this.physics.add.sprite(70 + this.x, 50, 'black');
		
		black.setBounce(1);
		
		
		
		black.body.immovable = true;
		this.bGroup.add(black);
		this.len++;
		this.x = this.x +110;

	}
	Phaser.Actions.ScaleXY(this.bGroup.getChildren(),-0.95,-0.95);

	ball = this.ball;
	player = this.player;
	//this.physics.add.collider(this.black, this.ball, ballHitBlack, null, this);
	
	
	this.ball.setBounce(1);
	this.player.setBounce(1);
	//this.black.setBounce(1);
	this.ball.setCollideWorldBounds(true);
	this.player.body.immovable = true;
}

mainsc.update = function(){
	

	if(this.go == false){
		this.player.x = this.input.x;}


	if(this.click == 0){
		this.ball.x = this.input.x;

	}

	if(this.input.mousePointer.isDown && this.start == 0){
		this.start = 1;
		this.click = 1;
		this.physics.moveTo(this.ball,this.input.x,this.input.y,500);
		introText.visible = false;

	}
	this.physics.add.collider(this.player, this.ball, ballHitPaddle, null, this);
	this.physics.add.collider(this.bGroup, this.ball, ballHitBlack, null, this);

	if(this.ball.y > this.player.y){
		gameOver();
		this.go = true;
	}

}

function ballHitPaddle (ball, player) {

    var diff = 0;

    if (this.ball.x < this.player.x)
    {
        //  Ball is on the left-hand side of the paddle
        diff = this.player.x - this.ball.x;
        this.ball.body.velocity.x = (-10 * diff);
    }
    else if (this.ball.x > this.player.x)
    {
        //  Ball is on the right-hand side of the paddle
        diff = this.ball.x -this.player.x;
        this.ball.body.velocity.x = (10 * diff);
    }
    else
    {
        //  Ball is perfectly in the middle
        //  Add a little random X to stop it bouncing straight up!
        this.ball.body.velocity.x = 2 + Math.random() * 8;
    }

}

ballHitBlack = function(black) {

	black.disableBody(true,true); 
	this.score = this.score + 1;
	scoreText.setText('score: ' + this.score);
}

function gameOver () {

    this.ball.body.velocity.setTo(0, 0);
    
    introText.setText('Game over');
    introText.visible = true;
    

}

var config = {
	type: Phaser.AUTO,
	width: 700,
	height: 417,
	scene: mainsc,
	physics: {
		default: 'arcade',
		gravity: false
	}
};

var start = new Phaser.Game(config);