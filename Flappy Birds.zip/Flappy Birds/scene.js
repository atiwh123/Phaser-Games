class mainSc{

	constructor(){

	}
	preload(){
		this.load.image('bird', 'assets/bird.png');
		this.load.image('pipe', 'assets/pipe.png');
		this.load.audio('jump', 'assets/jump.wav'); 
	}
	create(){
		this.jumpSound = this.sound.add('jump'); 
		this.birdAlive = true;
		this.score = 0;
		this.labelScore = this.add.text(20, 20, "0", 
    		{ font: "30px Arial", fill: "#ffffff" }); 
		this.bird = this.physics.add.sprite(100,245,'bird');
		//this.bird.setOrigin(0,0);
		this.bird.setGravityY(1000);


		this.j = this.input.keyboard.addKey('SPACE');

		this.pipes = this.physics.add.group(); 
		this.timer = this.time.addEvent({
	    delay: 1500,                
	    callback: this.addRowOfPipes,
	    callbackScope: this,
	    loop: true
	});
		this.physics.add.overlap(
	    this.bird, this.pipes, this.restartGame, null, this);
	}
	update(){
		if (this.bird.y < 0 || this.bird.y > 490){
        	this.restartGame();

		}


        if(this.input.keyboard.checkDown(this.j, 400)){
        	this.jump();

        	
        }

        if (this.bird.angle < 20)
    	this.bird.angle += 1; 	

	}
	jump(){
		if (this.birdAlive == false)
    	return; 

		this.tweens.add({
		        targets: this.bird,
		        angle:-50,
		        duration: 100,
		        ease: 'linear',
		        yoyo: false,
		        delay: 0
		    });
		this.bird.setVelocityY(-330);
		this.sound.play('jump'); 
	}
	restartGame(){
		if (this.birdAlive == false)
                return;
        this.birdAlive = false;
        this.timer.remove();
        this.pipes.propertyValueSet('visible', false);
		//this.scene.restart();
	}
	addOnePipe(x, y) {

    this.pipe = this.physics.add.sprite(x, y, 'pipe');
    //this.pipe.setOrigin(0,0);


    this.pipes.add(this.pipe);


    this.pipe.body.velocity.x = -200; 

    this.pipe.checkWorldBounds = true;
    this.pipe.outOfBoundsKill = true;
	}
	addRowOfPipes(){

	    // Randomly pick a number between 1 and 5
	    // This will be the hole position
	    this.hole = Math.floor(Math.random() * 5) + 1;

	    // Add the 6 pipes 
	    // With one big hole at position 'hole' and 'hole + 1'
	    for (var i = 0; i < 8; i++)
	        if (i != this.hole && i != this.hole + 1)
	            this.addOnePipe(400, i * 60 + 30);
	    this.score += 1;
		this.labelScore.setText(this.score);    
	}
}

var config = {
	type:Phaser.AUTO,
	width:400,
	height:490,
	backgroundColor:'#71c5cf',
	scene:mainSc,
	physics:{
		default:'arcade',
		        arcade:{
	                gravity:{y:0},
	                debug: false
            },
	}
};

var start = new Phaser.Game(config);